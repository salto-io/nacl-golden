---
layout: default
---
# SchemaRecipes class

Responsible for showing how to use schema and schema tokens

---
## Methods
### `schemaTokenRecipe()` → `void`

demonstrates how to use a field token for schema access

---
