---
layout: default
---
# LogSeverity enum

A top-level severity enum for Log, and LogMessage to use. @group Shared Code

---
